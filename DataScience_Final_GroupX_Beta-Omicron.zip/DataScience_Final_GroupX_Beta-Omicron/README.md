# Data Science Final Project

## Group Members (Names and IDs)
- BRYAN MAURICE TANYI BESONG - ICTU20234375
- PRECIOUS MALOBA SENGE ABENE - ICTU20233724
- MBAKOP SEUNDJI INES PASCALE - ICTU20234386
- TEMAH IAN SEUN SAMUEL NDOLO - ICTU20234062
- ROSE MARY LECHA NGWA MBENOH - ICTU20234079

## Project Title
Mobile Money Behavioral User Classification

## Brief Description
This project analyzes anonymized mobile money transactions to classify users into Low, Medium, and High activity segments using a complete data science workflow: collection, cleaning, EDA, modeling, interpretation, reporting, and presentation.

## File Structure Explanation
- `1_Data_Collection/`: anonymized raw dataset, consent form, questionnaire, and data collection report
- `2_Data_Cleaning/`: cleaning notebook, cleaned dataset, and cleaning report
- `3_EDA/`: EDA notebook, EDA report, and saved visualizations
- `4_Modeling/`: modeling notebook, saved best model, model comparison report, and metrics/results
- `5_Report/`: final report PDF and appendices
- `6_Presentation/`: presentation slides PDF (and optional demo note)
- `requirements.txt`: Python dependency list
- `CONTRIBUTIONS.md`: member-by-member contribution breakdown

## How To Run The Code
Run from the `combined` workspace:
- `python3 refresh_q1_q4_all5.py`
- `python3 generate_q5_interpretation.py`
- `python3 generate_final_package.py`

## Dependencies / Requirements
See `requirements.txt` for all libraries used.
