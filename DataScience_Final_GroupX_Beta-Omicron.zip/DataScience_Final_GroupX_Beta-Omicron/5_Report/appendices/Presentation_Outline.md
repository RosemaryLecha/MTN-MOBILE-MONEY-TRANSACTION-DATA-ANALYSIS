# Presentation Outline

1. Title and team
2. Problem statement and objective
3. Data sources and five-cohort structure
4. Data cleaning challenges and fixes
5. EDA highlights and 3 key visualizations
6. Segment definition and modeling setup
7. Model comparison results
8. Best model interpretation
9. Business recommendations
10. Limitations, ethics, and future work
11. Conclusion
12. Q&A