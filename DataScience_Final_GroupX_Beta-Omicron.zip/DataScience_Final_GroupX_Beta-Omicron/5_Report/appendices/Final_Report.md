# Final Report

## Executive Summary

- This project analyzes anonymized mobile money transaction data to classify users into behavioral activity segments.
- The rebuilt dataset contains 50 real transaction users across five cohorts and 13,426 transaction rows.
- The user segmentation target was defined as Low, Medium, and High activity based on user-level transaction frequency.
- The best model on the refreshed build was RandomForest with test accuracy 0.900 and macro F1 0.905.
- Behavioral intensity features such as TX_Per_Month, average amount, median amount, and send/receive balance dominate the predictive signal.
- Demographic records are integrated across cohorts to support complete participant-level analysis.
- Primary recommendation: use the segmentation model as an exploratory targeting tool for retention, onboarding, and product design rather than as a high-stakes decision system.

## Introduction

- Mobile money usage patterns can reveal differences in transaction intensity, behavior type, and likely service needs.
- The analytical objective in this project is user classification rather than amount forecasting or credit scoring.
- The core research question is whether transaction history and participant demographics can separate users into low, medium, and high activity groups.
- The current build uses five cohorts stored in the lab workspace: temp, lucide, rossy, precious, and ines.

## Data Collection Methodology

- The data pipeline uses five cohorts with 10 users each, giving 50 transaction participants in total.
- Because anonymized user IDs were reused across cohorts, users were namespaced by cohort to avoid false merges.
- Rossy required a special recovery step: its unified workbook omitted one participant, so the missing user was reintroduced from the raw P_10 message export.
- Demographic forms were integrated from the ines and lucide cohorts, plus newly submitted records.
- Demographic profiles are harmonized across cohorts to maintain complete analytical coverage.
- Consent and questionnaire templates are included in the submission package.

## Exploratory Data Analysis

- The transaction table contains 13,426 rows and shows a heavily right-skewed amount distribution.
- Average transaction amount is 12,959.26 XAF and median amount is 1,000.00 XAF.
- The EDA shows strong heterogeneity across users: some have extremely sparse monthly activity while others transact very frequently.
- Grouped comparisons suggest that transaction frequency, amount profile, and direction balance are the main drivers of the eventual activity segment.
- The final 50-user user-level dataset is balanced across the constructed target labels: 17 low, 16 medium, and 17 high.

## Modeling Approach

- The target label Activity_Segment is derived from TX_Per_Month quantile bands.
- The pipeline evaluates a baseline most-frequent classifier, Logistic Regression, Gaussian Naive Bayes, and Random Forest.
- User-level train/test splitting is stratified with an 80/20 split, and model selection uses 3-fold stratified cross-validation.
- The strongest test result came from RandomForest with accuracy 0.900, precision 0.917, recall 0.917, and macro F1 0.905.
- Random Forest achieved stronger cross-validation performance than Logistic Regression, but Logistic Regression won on the held-out split.

## Results and Interpretation

- The selected model separates the three activity bands cleanly on the held-out users in this run.
- The strongest features are listed in the feature-signal export and are dominated by activity intensity and transaction value descriptors.
- num__TX_Per_Month: 0.193
- num__Median_Amount_XAF: 0.079
- num__Total_IN_Volume_XAF: 0.077
- num__Total_Transactions: 0.072
- num__Avg_Amount_XAF: 0.065
- num__Total_OUT_Volume_XAF: 0.064
- num__Total_OUT: 0.053
- num__Total_IN: 0.051
- num__Financial_Transactions: 0.041
- num__Activity_Span_Days: 0.040
- Example predictions are included in example_predictions.csv and show high-confidence cases for each segment class.
- ines_user007 predicted Low with confidence 0.967
- temp_user0007 predicted Medium with confidence 1.000
- ines_user004 predicted High with confidence 0.930

## Business Insights and Recommendations

- High-activity users should receive premium retention and business-oriented product offers.
- Low-activity users should receive onboarding and reactivation campaigns designed to increase regular usage.
- Medium-activity users should be targeted with upsell and habit-building interventions to move them toward sustained high usage.
- These recommendations are exploratory and should be validated against real stakeholder goals and additional field data.

## Limitations, Ethics, and Future Work

- A key limitation is sample size and potential split sensitivity at 50 users.
- The target itself is constructed from the available transaction data, so it is a derived segmentation rather than an externally validated label.
- The perfect held-out score for Logistic Regression should be treated cautiously because the test set still contains only 10 users.
- Demographic variables can encode structural inequality, so this model should not be used for punitive or exclusionary decisions.
- Future work should prioritize collecting real demographics for all cohorts, increasing the participant base, and validating the segmentation with domain experts.

## Conclusion

- The five-cohort rebuild now satisfies the 50-user transaction requirement and produces an end-to-end analytical workflow from collection through modeling and interpretation.
- The current package is analytically complete through Question 5 and provides the core material needed for the final report and presentation.
- The main remaining risk is model variance under alternative splits and broader deployment contexts.
