# Contributions

- Data extraction and cohort preparation: temp, lucide, precious, rossy, jerry source integration
- Data cleaning and feature engineering: refreshed 50-user transaction and user-level datasets
- EDA and visualization: question 3 reports, plots, and crosstabs
- Modeling and evaluation: baseline plus Logistic Regression, GaussianNB, and Random Forest
- Interpretation and reporting: question 5 outputs and final package assembly

Replace this file with the actual team-member breakdown before submission.